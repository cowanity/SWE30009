- The "results" folder will be generate inside "mutants" folder.

Thanks for reading.
Vu Phan